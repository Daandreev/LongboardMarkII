                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1677410
Longboard Orangatang Kegel 36 Tooth Pulley for 9mm, 12MM and 15mm Belt by JuniourPotato93 is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

July 19th, 2016: Updated the files due to some tolerancing issues. I reprinted the mating component of all 3 pulleys and Flatface adaptor, you should have no issues going forward.

The pre-bored holes are intended for 10-24 tap. If you dont have access to a tap, you can drill these out a little larger using a number 25 drill bit for imperial (.150")  which is 3.81mm in metric so 4mm would also work. Once you secure a good fit on your wheels, a small drop of superglue on the threads of the screw is encouraged to prevent the screws from coming loose due to vibrations.

10-24 by 2 Inch Machine Screws work perfectly with this design and will not hit your trucks (Caliber or Paris) and probably other though I have not tested others myself.

No modifications to your trucks are required for use.

Enjoy.